const SOURCES = [
  {n:"Rentry", g:["quick","text"], score:"Best", d:"أفضل موقع نصي للتجربة الأولى", q:'site:rentry.co "{q}" mega.nz'},
  {n:"Rentry File / Folder", g:["quick","text"], score:"Best", d:"يبحث عن صفحات Rentry التي قد تحتوي روابط مباشرة", q:'site:rentry.co "{q}" ("mega.nz/file/" OR "mega.nz/folder/")'},
  {n:"Pastebin", g:["quick","text"], score:"High", d:"نصوص وروابط عامة", q:'site:pastebin.com "{q}" mega.nz'},
  {n:"Pastelink", g:["quick","text"], score:"High", d:"صفحات روابط نصية", q:'site:pastelink.net "{q}" mega.nz'},
  {n:"JustPaste", g:["quick","text"], score:"High", d:"نصوص وروابط عامة", q:'site:justpaste.it "{q}" mega.nz'},
  {n:"Paste.ee", g:["quick","text"], score:"High", d:"موقع نشر نصوص", q:'site:paste.ee "{q}" mega.nz'},
  {n:"ControlC", g:["text"], score:"Medium", d:"موقع نصوص", q:'site:controlc.com "{q}" mega.nz'},
  {n:"PasteCode", g:["text"], score:"Medium", d:"نصوص وأكواد", q:'site:pastecode.io "{q}" mega.nz'},
  {n:"GitHub Gist", g:["text"], score:"Medium", d:"صفحات نصية مفهرسة", q:'site:gist.github.com "{q}" mega.nz'},
  {n:"Linktree", g:["links"], score:"Links", d:"صفحات روابط شخصية", q:'site:linktr.ee "{q}" (mega.nz OR mega.io OR linkvertise.com OR meawfy.com)'},
  {n:"Linkvertise", g:["links"], score:"Links", d:"بحث فقط، دون تجاوز unlock", q:'site:linkvertise.com "{q}" (mega.nz OR mega.io)'},
  {n:"Meawfy", g:["links"], score:"Links", d:"بحث فقط، دون تجاوز credits", q:'site:meawfy.com "{q}" (mega.nz OR mega.io)'},
  {n:"Telegram Public", g:["deep"], score:"Deep", d:"قنوات عامة مفهرسة", q:'site:t.me "{q}" mega.nz'},
  {n:"Reddit", g:["deep"], score:"Deep", d:"مناقشات عامة", q:'site:reddit.com "{q}" mega.nz'},
  {n:"General Exact", g:["deep"], score:"Deep", d:"بحث عام صارم", q:'"{q}" ("mega.nz/file/" OR "mega.nz/folder/" OR "mega.io/file/" OR "mega.io/folder/")'},
  {n:"General Broad", g:["deep"], score:"Deep", d:"بحث عام أوسع", q:'"{q}" mega.nz'}
];

let currentUrls = [];

function googleUrl(query){
  return "https://www.google.com/search?q=" + encodeURIComponent(query).replaceAll("%20","+") + "&tbs=qdr:m3";
}
function cleanQuery(v){return v.trim().replaceAll('"',"");}
function runSearch(mode){
  const raw = document.getElementById("query").value.trim();
  const results = document.getElementById("results");
  const summary = document.getElementById("summary");
  results.innerHTML = ""; currentUrls = [];
  if(!raw){summary.textContent="اكتب اسم الملف أو الكلمة أولاً."; return;}
  saveHistory(raw);
  const q = cleanQuery(raw);
  const list = SOURCES.filter(s => mode==="deep" ? true : s.g.includes(mode));
  summary.textContent = "تم تجهيز " + list.length + " عملية بحث — فلتر آخر 3 أشهر عند استخدام Google.";
  list.forEach((s, idx)=>{
    const query = s.q.replaceAll("{q}", q);
    const url = googleUrl(query);
    currentUrls.push(url);
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `<span class="tag">${s.score}</span>
      <h3>${s.n}</h3>
      <p>${s.d}<br><b>Query:</b> ${query}</p>
      <div class="row">
        <a class="btn" target="_blank" rel="noopener" href="${url}">فتح</a>
        <button class="copy" onclick="copyOne('${encodeURIComponent(url)}')">نسخ</button>
      </div>`;
    results.appendChild(div);
  });
  renderHistory();
}
function openBest(){
  if(currentUrls.length===0) runSearch("quick");
  currentUrls.slice(0,5).forEach((url,i)=>setTimeout(()=>window.open(url,"_blank"), i*650));
}
async function copyOne(encoded){
  await navigator.clipboard.writeText(decodeURIComponent(encoded));
  alert("تم النسخ");
}
async function copyAll(){
  if(currentUrls.length===0) runSearch("quick");
  await navigator.clipboard.writeText(currentUrls.join("\n"));
  alert("تم نسخ كل روابط البحث");
}
function saveHistory(q){
  let h = JSON.parse(localStorage.getItem("mh_history") || "[]");
  h = [q, ...h.filter(x=>x!==q)].slice(0,10);
  localStorage.setItem("mh_history", JSON.stringify(h));
}
function renderHistory(){
  const box = document.getElementById("history");
  const h = JSON.parse(localStorage.getItem("mh_history") || "[]");
  box.innerHTML = h.length ? "" : '<span class="chip">لا يوجد سجل</span>';
  h.forEach(x=>{
    const b=document.createElement("button");
    b.className="chip"; b.textContent=x;
    b.onclick=()=>{document.getElementById("query").value=x; runSearch("quick");};
    box.appendChild(b);
  });
}
function clearHistory(){localStorage.removeItem("mh_history"); renderHistory();}
function installHelp(){alert("من Safari اضغط Share ثم Add to Home Screen.");}
if("serviceWorker" in navigator){navigator.serviceWorker.register("sw.js");}
renderHistory();
