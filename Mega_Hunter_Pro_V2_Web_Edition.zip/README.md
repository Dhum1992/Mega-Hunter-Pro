# Mega Hunter Pro V2

Personal public-search PWA for finding pages that may contain public MEGA links.

## Rules

- Does not bypass login, ads, unlock, credits, or protections.
- Uses public search queries only.
- Works with the existing MEGA Extractor shortcut.

## Deploy

Upload all files to GitHub repository root, then enable GitHub Pages from the main branch.
